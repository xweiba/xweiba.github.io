package com.wb.service;

import com.spring.ApplicationContextAware;
import com.spring.Component;
import com.spring.Scope;
import com.spring.WbAnnotationSpringApplication;

@Component
@Scope("prototype")
public class OrderInfoService implements ApplicationContextAware {

    private WbAnnotationSpringApplication context;

    @Override
    public void setApplicationContext(WbAnnotationSpringApplication context) {
        this.context = context;
    }

    public WbAnnotationSpringApplication getContext() {
        return context;
    }
}
