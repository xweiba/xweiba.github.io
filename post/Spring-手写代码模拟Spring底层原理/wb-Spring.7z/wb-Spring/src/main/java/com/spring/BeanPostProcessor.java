package com.spring;

import com.sun.istack.internal.Nullable;

/**
 * @author wb
 * @date 2022/12/8 17:23
 **/
public interface BeanPostProcessor {


    @Nullable
    default Object postProcessBeforeInitialization(Object bean, String beanName){
        return bean;
    }

    @Nullable
    default Object postProcessAfterInitialization(Object bean, String beanName) {
        return bean;
    }

}
