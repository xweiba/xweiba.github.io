package com.wb;

import com.spring.ComponentScan;

/**
 * @author caleb_L
 * @date 2022/12/8
 **/

@ComponentScan("com.wb.service")
public class AppConfig {

}
