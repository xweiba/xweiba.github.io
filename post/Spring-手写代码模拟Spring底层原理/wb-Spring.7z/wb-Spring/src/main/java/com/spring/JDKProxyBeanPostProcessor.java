package com.spring;

/**
 * @author wb
 * @date 2022/12/8
 **/

//@Component
public class JDKProxyBeanPostProcessor implements BeanPostProcessor {

    // JDK动态代理只能基于接口实现

}
