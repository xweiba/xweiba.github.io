package com.spring;

import com.spring.cglib.CglibProxyBeanPostProcessor;
import com.sun.org.apache.xpath.internal.objects.XNull;
import jdk.nashorn.internal.runtime.arrays.IntOrLongElements;

import java.beans.Introspector;
import java.io.File;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author caleb_L
 **/

public class WbAnnotationSpringApplication {

    private static final Map<String, BeanDefinition> beanDefinitionMap = new HashMap<>();

    // Spring 中使用的是LinkList
    private static final List<BeanPostProcessor> beanPosetProcessorList = new ArrayList<BeanPostProcessor>(){{
        add(new CglibProxyBeanPostProcessor());
    }};
    private static final Map<Class, Object> singleMap = new HashMap<>();

    public WbAnnotationSpringApplication(Class clazz) {

        // 1. 扫描BeanDefinition
        scanBeanDefinition(clazz);

        // 2. 通过BeanDefinition创建Bean
        for (BeanDefinition beanDefinition : beanDefinitionMap.values()) {
            if (beanDefinition.isLazy() || beanDefinition.getScope().equals("prototype")) {
                continue;
            }
            if (null == singleMap.get(beanDefinition.getClazz())) {
                doCreateBean(beanDefinition);
            }
        }
    }

    private Object doCreateBean(BeanDefinition beanDefinition) {
        String beanName = beanDefinition.getBeanName();

        // 实例化
        try {
            Class beanClazz = beanDefinition.getClazz();
            Object obj = beanClazz.newInstance();

            // 执行 BeanPostProcessor 的bean生成前方法
            for (BeanPostProcessor beanPostProcessor : beanPosetProcessorList) {
                obj = beanPostProcessor.postProcessBeforeInitialization(obj, beanName);
            }

            // 属性注入, 注意属性必须是public的, 否则get不到
            for (Field beanField : beanClazz.getFields()) {
                if (beanField.isAnnotationPresent(Autowired.class)) {
                    Autowired annotation = beanField.getAnnotation(Autowired.class);
                    String beanFieldName = annotation.value();
                    if ("".equals(beanFieldName)) {
                        beanFieldName = Introspector.decapitalize(beanField.getType().getSimpleName());
                    }
                    beanField.setAccessible(true);
                    beanField.set(obj, getBean(beanFieldName));
                }
            }

            // 执行 BeanPostProcessor 的bean生成后方法
            for (BeanPostProcessor beanPostProcessor : beanPosetProcessorList) {
                obj = beanPostProcessor.postProcessAfterInitialization(obj, beanName);
            }

            // Spring 另外一个非常重要的接口, 在Bean生成完毕后回调其方法.
            if (obj instanceof Aware) {
                if (obj instanceof ApplicationContextAware) {
                    ((ApplicationContextAware)obj).setApplicationContext(this);
                }
            }

            if (beanDefinition.getScope().equals("singleType")) {
                singleMap.put(beanClazz, obj);
            }
            return obj;
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }

        return null;
    }

    private void scanBeanDefinition(Class clazz) {
        // 1. 判断clazz 是否含有 ComponentScan 注解
        if (clazz.isAnnotationPresent(ComponentScan.class)) {

            // 2. 通过 ComponentScan 的 value 扫描包下的所有 class
            ComponentScan componentScanAnnotation = (ComponentScan) clazz.getAnnotation(ComponentScan.class);
            // com.wb.service
            String value = componentScanAnnotation.value();

            // 注意这里执行的时候是运行时环境, class存放的路径是动态的,在idea下是target 目录下, 由 idea 启动时通过javaagent方法传入,我们不太好获取到绝对路径, 但是有一个可以获取到, 你猜猜是什么?

            // 那就是我们的ClssLoader.
            // 我们的类加载器分为 BootClassLoader启动类加载器(JVM实现)加载核心类库, ExtClassLoader 扩展类加载器 和 AppClassLoader 应用类加载器
            ClassLoader classLoader = clazz.getClassLoader();

            // 我们需要将. 替换为文件路径
            String path = value.replace(".", "/");
            URL resources = classLoader.getResource(path);

            // 获取目录文件
            File fileDir = new File(resources.getFile());
            if (fileDir.isDirectory()) {
                for (File file : fileDir.listFiles()) {
                    // 开始解析包下的class文件, 我们如何从文件读取class信息?
                    // 答案还是我们的ClassLoader
                    try {
                        // classLoader.loadClass 是通过class Name查找的
                        String absolutePath = file.getAbsolutePath();
                        String classPath = absolutePath.substring(absolutePath.lastIndexOf("\\classes\\") + "\\classes\\".length(), absolutePath.lastIndexOf(".class"));
                        String classPackgeName = classPath.replace("\\", ".");
                        Class<?> fileClass = classLoader.loadClass(classPackgeName);

                        // 判断是否包含 @Component 注解
                        if (fileClass.isAnnotationPresent(Component.class)) {
                            // 获取注解值当做 BeanName
                            Component componentAnnotation = fileClass.getAnnotation(Component.class);
                            String beanName = componentAnnotation.value();

                            if (null == beanName || "".equals(beanName)) {
                                // 核心类库自带方法
                                beanName = Introspector.decapitalize(fileClass.getSimpleName());
                            }

                            // 注意 还有一个非常重要的接口我们没有检测, 在Bean创建前和创建后都可以做一些处理, 这个是怎么实现的?
                            // 就是我们 Spring 中非常重要的一个接口 BeanPostProcessor, 他有两个接口, Spring的核心中的核心
                            if (BeanPostProcessor.class.isAssignableFrom(fileClass)) {
                                BeanPostProcessor instance = (BeanPostProcessor)fileClass.getConstructor().newInstance();
                                // 我们需要把他缓存起来
                                beanPosetProcessorList.add(instance);
                                continue;
                            }

                            // 获取到BeanDefinition之后是否直接实例化???
                            // 如果直接实例化会有什么问题?
                            // 通过上次的底层核心原理大致解析, 我们知道Bean在创建过程中还需要做很多其他的事情,如果此时实例化的话后面会非常不好处理,
                            // 我们可以先将所有需要注入的Bean全部缓存起来, 等所有的Bean信息都收集完毕后 再进一步处理.
                            // 我们需要一个存放Bean信息的对象. BeanDefinition
                            BeanDefinition beanDefinition = new BeanDefinition();
                            beanDefinition.setClazz(fileClass);
                            beanDefinition.setBeanName(beanName);

                            // 单例还是多例
                            if (fileClass.isAnnotationPresent(Scope.class)) {
                                Scope annotation = fileClass.getAnnotation(Scope.class);
                                beanDefinition.setScope(annotation.value());
                            }

                            // 是否为懒加载
                            if (fileClass.isAnnotationPresent(Lazy.class)) {
                                Lazy annotation = fileClass.getAnnotation(Lazy.class);
                                beanDefinition.setLazy(annotation.value());
                            }

                            // 将 BeanDefinition 缓存起来
                            beanDefinitionMap.put(beanName, beanDefinition);

                        }

                    } catch (ClassNotFoundException e) {
                        e.printStackTrace();
                    } catch (InvocationTargetException e) {
                        e.printStackTrace();
                    } catch (InstantiationException e) {
                        e.printStackTrace();
                    } catch (IllegalAccessException e) {
                        e.printStackTrace();
                    } catch (NoSuchMethodException e) {
                        e.printStackTrace();
                    }

                }
            }
        }
    }

    public Object getBean(String beanName) {
        // 可能是懒加载 所以需要通过BeanDefinitionMap获取
        BeanDefinition beanDefinition = beanDefinitionMap.get(beanName);
        Object obj = null;
        if (null != beanDefinition) {
            if (beanDefinition.getScope().equals("singleType")) {
                obj = singleMap.get(beanDefinition.getClazz());
                // 懒加载
                if (null == obj) {
                    System.out.println("懒加载");
                    obj = doCreateBean(beanDefinition);
                }
            } else {
                System.out.println("原型Bean");
                obj = doCreateBean(beanDefinition);
            }
        }
        return obj;
    }
}
