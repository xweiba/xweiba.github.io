package com.spring;

/**
 * @author wb
 * @date 2022/12/8
 **/

public interface ApplicationContextAware extends Aware{

    void setApplicationContext(WbAnnotationSpringApplication context);

}
