package com.spring;

/**
 * @author wb
 * @date 2022/12/8
 **/

public class BeanDefinition {

    private String beanName;

    public String getBeanName() {
        return beanName;
    }

    public void setBeanName(String beanName) {
        this.beanName = beanName;
    }

    private Class clazz;

    // 单例还是原型(多例) singleType || prototype
    private String scope = "singleType";

    // 是否懒加载
    private boolean isLazy;


    public Class getClazz() {
        return clazz;
    }

    public void setClazz(Class clazz) {
        this.clazz = clazz;
    }

    public String getScope() {
        return scope;
    }

    public void setScope(String scope) {
        this.scope = scope;
    }

    public boolean isLazy() {
        return isLazy;
    }

    public void setLazy(boolean lazy) {
        isLazy = lazy;
    }
}
