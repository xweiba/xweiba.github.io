package com.spring;

/**
 * @author wb
 * @date 2022/12/8 17:37
 **/
public interface Aware {

}
