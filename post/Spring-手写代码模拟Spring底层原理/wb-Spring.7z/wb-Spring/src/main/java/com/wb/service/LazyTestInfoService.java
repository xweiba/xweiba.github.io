package com.wb.service;

import com.spring.*;

@Component
@Lazy(true)
public class LazyTestInfoService implements ApplicationContextAware {

    private WbAnnotationSpringApplication context;

    @Override
    public void setApplicationContext(WbAnnotationSpringApplication context) {
        this.context = context;
    }
}
