package com.wb;

import com.spring.WbAnnotationSpringApplication;
import com.wb.service.UserInfoService;

/**
 * @author wb
 **/

public class WbTest {

    public static void main(String[] args) {

        WbAnnotationSpringApplication context = new WbAnnotationSpringApplication(AppConfig.class);

        UserInfoService userInfoService = (UserInfoService) context.getBean("userInfoService");
        userInfoService.test();

        System.out.println(context.getBean("userInfoService"));

        System.out.println(context.getBean("orderInfoService"));

        System.out.println(context.getBean("lazyTestInfoService"));
    }
}
