package com.spring.cglib;

import net.sf.cglib.proxy.MethodInterceptor;
import net.sf.cglib.proxy.MethodProxy;

import java.lang.reflect.Method;

/**
 * @author wb
 * @date 2022/12/8
 **/

public class CglibProxyMethInterceptor implements MethodInterceptor {

    private Object target;

    public CglibProxyMethInterceptor(Object target) {
        this.target = target;
    }

    @Override
    public Object intercept(Object o, Method method, Object[] objects, MethodProxy methodProxy) throws Throwable {
        System.out.println("CglibProxyMethInterceptor Before " + method.toString());
        Object invoke = method.invoke(target, objects);
        System.out.println("CglibProxyMethInterceptor after " + method.toString());
        return invoke;
    }
}
