package com.wb.service;

import com.spring.Autowired;
import com.spring.Component;

@Component
public class UserInfoService {

    @Autowired
    public OrderInfoService orderInfoService;

    public void test(){
        System.out.println("test:" + orderInfoService.getContext());
    }

}
