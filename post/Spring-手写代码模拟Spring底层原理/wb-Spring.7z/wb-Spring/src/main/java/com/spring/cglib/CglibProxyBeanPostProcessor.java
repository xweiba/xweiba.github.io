package com.spring.cglib;

import com.spring.BeanPostProcessor;
import com.spring.Component;
import com.spring.cglib.CglibProxyMethInterceptor;
import net.sf.cglib.proxy.Enhancer;

/**
 * @author wb
 * @date 2022/12/8
 **/

public class CglibProxyBeanPostProcessor implements BeanPostProcessor {

    // Gclib 动态代理基于继承实现
    @Override
    public Object postProcessAfterInitialization(Object bean, String beanName) {
        return Enhancer.create(bean.getClass(), new CglibProxyMethInterceptor(bean));
    }

}
